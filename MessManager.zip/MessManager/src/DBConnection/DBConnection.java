/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DBConnection;
import java.sql.*;
/**
 *
 * @author whyanujjwhy
 */
public class DBConnection {
    public static Connection getConnection() throws Exception {
        Connection con=null;
        try {
            String url="jdbc:mysql://localhost/messmanager";
            String uname="root";
            String pwd="";
            Class.forName("com.mysql.cj.jdbc.Driver");
            con=DriverManager.getConnection(url, uname, pwd);
        }
        catch(Exception e) {
            System.out.println(e);
        }
        return con;
    }
}
