/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package messmanager;

/**
 *
 * @author whyanujjwhy
 */
public class messModel {
    String MessName, McName, Cap, Avail;
}
